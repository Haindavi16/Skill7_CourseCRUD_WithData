package com.klu.inventory.service;

import com.klu.inventory.model.Course;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CourseService {

    private List<Course> courseList = new ArrayList<>();

    public CourseService() {
        // Pre-added course
        courseList.add(new Course(1, "Spring Boot", "3 Months", 8000));
    }

    public Course addCourse(Course course) {
        courseList.add(course);
        return course;
    }

    public List<Course> getAllCourses() {
        return courseList;
    }

    public Optional<Course> getCourseById(int id) {
        return courseList.stream()
                .filter(c -> c.getCourseId() == id)
                .findFirst();
    }

    public Optional<Course> updateCourse(int id, Course updatedCourse) {
        Optional<Course> existing = getCourseById(id);
        existing.ifPresent(course -> {
            course.setTitle(updatedCourse.getTitle());
            course.setDuration(updatedCourse.getDuration());
            course.setFee(updatedCourse.getFee());
        });
        return existing;
    }

    public boolean deleteCourse(int id) {
        return courseList.removeIf(c -> c.getCourseId() == id);
    }

    public List<Course> searchByTitle(String title) {
        return courseList.stream()
                .filter(c -> c.getTitle().equalsIgnoreCase(title))
                .toList();
    }
}
