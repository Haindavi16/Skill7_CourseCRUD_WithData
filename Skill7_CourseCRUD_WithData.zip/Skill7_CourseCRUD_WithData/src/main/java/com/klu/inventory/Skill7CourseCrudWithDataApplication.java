package com.klu.inventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Skill7CourseCrudWithDataApplication {

    public static void main(String[] args) {
        SpringApplication.run(Skill7CourseCrudWithDataApplication.class, args);
    }
}
