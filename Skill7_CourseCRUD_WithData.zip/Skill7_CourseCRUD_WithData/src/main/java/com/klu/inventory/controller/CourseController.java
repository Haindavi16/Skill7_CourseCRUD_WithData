package com.klu.inventory.controller;

import com.klu.inventory.model.Course;
import com.klu.inventory.service.CourseService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/courses")
public class CourseController {

    private final CourseService courseService;

    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    @PostMapping
    public ResponseEntity<?> addCourse(@RequestBody Course course) {
        if (course.getCourseId() <= 0) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Invalid Course ID");
        }

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(courseService.addCourse(course));
    }

    @GetMapping
    public ResponseEntity<List<Course>> getAllCourses() {
        return ResponseEntity.ok(courseService.getAllCourses());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getCourseById(@PathVariable int id) {
        return courseService.getCourseById(id)
                .map(course -> ResponseEntity.ok(course))
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("Course Not Found"));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateCourse(@PathVariable int id,
                                          @RequestBody Course course) {

        return courseService.updateCourse(id, course)
                .map(updated -> ResponseEntity.ok(updated))
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("Course Not Found"));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteCourse(@PathVariable int id) {

        if (courseService.deleteCourse(id)) {
            return ResponseEntity.ok("Course Deleted Successfully");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Course Not Found");
        }
    }

    @GetMapping("/search/{title}")
    public ResponseEntity<List<Course>> searchByTitle(@PathVariable String title) {
        return ResponseEntity.ok(courseService.searchByTitle(title));
    }
}
